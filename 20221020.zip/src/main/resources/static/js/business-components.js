

var businessHeaderComponent = Vue.extend({
    
});