package online.buza.blog.exception;


public class CaptchaException extends RuntimeException {

    public CaptchaException(String msg) {
        super(msg);
    }
}
